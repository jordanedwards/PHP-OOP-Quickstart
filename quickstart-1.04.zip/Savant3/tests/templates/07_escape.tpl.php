<?php echo $this->escape($this->text) ?>

<?php $this->eprint($this->text) ?>