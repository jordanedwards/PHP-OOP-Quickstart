<?php
	ob_start();
	session_start();
	date_default_timezone_set("America/Vancouver");
	$base_folder = "http://orchardcity.ca/invoices/";

	$includes_folder = "http://orchardcity.ca/invoices/includes";
	$class_folder = "http://orchardcity.ca/invoices/classes";
	$actions_folder = "http://orchardcity.ca/invoices/actions";

	require_once($includes_folder . '/includes/config_app.php');
	require_once($class_folder . '/classes/class_session_manager.php');
	require_once($class_folder . '/classes/class_functions.php');
	
	$session = new SessionManager();
		
	$alert_msg = $session->getAlertMessage();
	$alert_color = $session->getAlertColor();
	
	$admin_email = "jordan@test.net";

// ****************************************** SET TO YOUR LOGIN & YOUR LOGIN ACTION PAGE **********************************			
	if ($_SERVER['PHP_SELF'] != "/index.php" && $_SERVER['PHP_SELF'] != "/actions/action_login_user.php"){
		if($session->get_user_id() == "") {
		$current_adr = str_replace("?","*",$_SERVER["REQUEST_URI"]);
		$current_adr = str_replace("&","~",$current_adr);
// ****************************************** SET TO YOUR LOGIN PAGE **********************************		
		header("location:/index.php?redirect=".$current_adr );
		exit;
		}
	}