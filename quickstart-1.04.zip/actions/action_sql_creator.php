<?php /*
foreach ($_POST as $key => $val){
			echo $key . " - " . $val."<br>";
	}

exit();*/
$table_name = $_POST['table_name'];

  header('Content-disposition: attachment; filename='.$table_name.'.sql');
  header ("Content-Type:text/sql");  
	
?>

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS `<?php echo $table_name ?>` (
`<?php echo $table_name ?>_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
<?php 
foreach($_POST as $key => $value) {
	if (substr($key,0,5) == "field"){
		echo "`" . $table_name . "_" . $value . "` ";
	}
	if (substr($key,0,4) == "type"){
		echo $value . " NOT NULL,
";
	}
}
?>`<?php echo $table_name ?>_date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
`<?php echo $table_name ?>_last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
`<?php echo $table_name ?>_last_updated_user` varchar(200) NOT NULL DEFAULT '0',
  
PRIMARY KEY (`<?php echo $table_name ?>_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

