<?php
//*********************************************************************************
// Mail Configuration File
//*********************************************************************************
	$mailConfig["mail_server"] = "mail.netook.ca";
	$mailConfig["mail_mailer"] = "smtp";
	$mailConfig["mail_smtpauth"] = true;
	$mailConfig["mail_port"] = "587";
	$mailConfig["mail_username"] = "website@netook.ca";
	$mailConfig["mail_password"] = "fs3fd@333ds";
	
	$mailConfig["mail_from"] = "website@netook.ca";
	$mailConfig["mail_fromname"] = "website@netook.ca";
	$mailConfig["mail_sender"] = "website@netook.ca";
	$mailConfig["mail_admin"] = "website@netook.ca";
?>
